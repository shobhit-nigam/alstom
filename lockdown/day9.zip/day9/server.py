import socket
import time
steps = """
create a socket object
reserve a port
bind 
listen
accept
communication starts
	send-recive
"""

objs = socket.socket()
print("socket object created")
port = 15000
ip = ''
objs.bind((ip, port))
print("socket is binded")
objs.listen(2)
print("listening...")
while True:
	cobj, adress = objs.accept()
	print("connected")
	stra = "connected !!!"
	cobj.sendall(stra.encode('utf-8'))
#	time.sleep(5);
#	cobj.send("will close connection now")
	cobj.close()


