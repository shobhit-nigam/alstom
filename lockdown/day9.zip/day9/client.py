import socket

steps = """
create a socket object
define a port

connect

communicating
	send - recv
"""

objs = socket.socket()
port = 15000

objs.connect(('127.0.0.1', port))

data = objs.recv(4096)
print(data)
#data = objs.recv(4096)
#print(data)
objs.close()
