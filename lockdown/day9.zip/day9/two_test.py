def testfunca():
	assert 100 == 200

def testfuncb():
	varx = 10
	assert 10*10 == 100
