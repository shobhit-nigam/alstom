def funca():
       print("hello")
        
def funcb():
    print("hi")
    
print("name = ", __name__)

if __name__ == '__main__':
    open("hello.txt", "w")
    
    def funcc():
        print("hi hello")



#    stores name = "__main__"
#    name = "__moda__"