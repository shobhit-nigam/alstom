def testfunca():
	assert 100 == 200
