print("hello world")
4 + 3
print("welcome everyone")
