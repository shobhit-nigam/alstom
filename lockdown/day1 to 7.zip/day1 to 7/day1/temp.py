print("hello")
7+10
print("hi")
