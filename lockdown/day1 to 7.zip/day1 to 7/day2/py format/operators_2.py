#!/usr/bin/env python
# coding: utf-8

# In[1]:


ba = True


# In[2]:


bb = False


# In[3]:


type(ba)


# In[4]:


bc = false


# In[5]:


listx = [23, 7, True, "hi", None]


# In[6]:


vara = 20
varb = 30
varc = 0


# In[7]:


vara and varc


# In[8]:


vara < varb


# In[9]:


varb < varc


# In[10]:


vara < varb < 70


# In[11]:


vara < varb and varb < 70


# In[12]:


listx = [23, 7, True, "hi", None]


# In[13]:


23 in listx


# In[14]:


45 in listx


# In[15]:


print(type(listx))


# In[16]:


type(listx)


# In[17]:


type(listx) is list


# In[18]:


setc = {'kiwi', ('banana', 'orange'), 'apple'}


# In[19]:


type(setc) is not dict


# In[ ]:




