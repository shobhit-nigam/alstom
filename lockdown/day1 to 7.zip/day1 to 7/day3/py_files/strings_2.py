#!/usr/bin/env python
# coding: utf-8

# In[1]:


stra = """first line
anothe line
yet another line
and last line
"""


# In[2]:


print(stra)


# In[3]:


stra


# In[4]:


#   documentation


# In[5]:


help(type)


# In[6]:


help(id)


# In[8]:


print(stra.upper())


# In[9]:


strb = "mere paas maa hai"


# In[10]:


strb.split()


# In[11]:


lista = strb.split()


# In[12]:


print(lista)


# In[13]:


strb.sort()


# In[15]:


listb = sorted(strb)


# In[16]:


print(listb)


# In[17]:


strc = "India"
listc = sorted(strc)


# In[18]:


print(listc)


# In[19]:


#   ascii values of upper case are lower than those of lower case


# In[20]:


listd = [6, 8, 2, 13, 4]


# In[21]:


sorted(listd)


# In[22]:


print(listd)


# In[23]:


listd.sort()


# In[24]:


strn = "7854"


# In[25]:


strm = "76ers"


# In[26]:


strn.isalnum()


# In[27]:


strn.isnumeric()


# In[28]:


strm.isnumeric()


# In[29]:


strn.isalpha()


# In[30]:


help(strm.istitle)


# In[31]:


print(stra)


# In[32]:


listx = stra.splitlines()


# In[33]:


print(listx)


# In[35]:


pass


# In[ ]:




