#!/usr/bin/env python
# coding: utf-8

# In[1]:


def red():
    print("scarlet red")


# In[2]:


def blue():
    print("cool blue")


# In[3]:


def magenta():
    print("magenta, mixture of")
    red()
    blue()


# In[ ]:




