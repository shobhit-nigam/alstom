"hello this is Karun"

print("hello")

def green():
    print("go green")
    
data1 = 23
data2 = 33

def white():
    print("kora kagaz")