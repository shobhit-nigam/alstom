#!/usr/bin/env python
# coding: utf-8

# In[1]:


#   pandas, numpy
#   visualisation libraries (example matplotlib)


# In[2]:


import time


# In[3]:


import pandas as pd


# In[4]:


import numpy as np


# In[5]:


dfa = pd.read_csv('matches.csv')


# In[6]:


#    DataFrame


# In[7]:


dfa.shape


# In[8]:


dfa.head(7)


# In[9]:


dfa


# In[10]:


dfa.columns


# In[12]:


dfa.info()


# In[13]:


#   pnadas uses numpy


# In[14]:


col = list(dfa.columns)


# In[15]:


col


# In[16]:


#    NaN


# In[20]:


dfa.isna().sum()


# In[21]:


dfa[8:11]


# In[22]:


dfa.head(10)


# In[23]:


food = pd.read_csv('food.csv')


# In[24]:


food


# In[31]:


food.sort_values('price')


# In[34]:


food[ ['item', 'price'] ]


# In[35]:


food.rename(columns={'Unnamed: 0':'my_index'})


# In[36]:


food


# In[37]:


food.rename(columns={'Unnamed: 0':'my_index'}, inplace=True)


# In[38]:


food


# In[40]:


food.columns


# In[42]:


food.to_csv("new_food.csv", index=False)


# In[43]:


new_food = pd.read_csv('new_food.csv')


# In[44]:


new_food


# In[45]:


food.to_csv("food.csv", index=False)


# In[46]:


food = pd.read_csv('food.csv')


# In[47]:


food


# In[ ]:




