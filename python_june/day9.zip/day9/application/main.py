def sample_main():
    print("main")