#!/usr/bin/env python
# coding: utf-8

# In[1]:


def gone():
    print("green one")


# In[ ]:




