def bone():
    print("blue one")
    
def btwo():
    print("blue two")

