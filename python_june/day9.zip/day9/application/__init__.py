from . import main
from .folder_1 import blue