print("hello")
4 + 3
varx = 33
print(10+12)
