def red():
    print("scarlet red")
    
def white():
    print("white, sum of all colours, purity")
    
def pink():
    print("pink is sum of red & white")
    red()
    white()
    