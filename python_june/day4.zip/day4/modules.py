#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time


# In[3]:


print("some code")
time.sleep(4)
print("some extra code")


# In[4]:


import os 
import sys


# In[5]:


os.getcwd()


# In[6]:


os.mkdir('sample')


# In[8]:


print(sys.version)


# In[ ]:




