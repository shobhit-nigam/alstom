data1 = 33
data2 = 75

def red():
    print("pure red")
    
def yellow():
    print("pure yellow")
    
def karunadu():
    print("karu nadu flag")
    red()
    yellow()
