data1 = 33

def chutney():
    print("chutney goes with anything")
    
def chapathi():
    print("healthy wheat staple food")
    
data2 = 'new' 
    
def rice():
    print("south india's pride")