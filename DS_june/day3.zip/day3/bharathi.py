def pasta():
    print("pasta with white sauce")
    
def batter():
    print("soaked overnight")
    print("grinded well")
    
def dosa():
    batter()
    print("spread & baked on tawa")
    
def idli():
    batter()
    print("steamed wel")